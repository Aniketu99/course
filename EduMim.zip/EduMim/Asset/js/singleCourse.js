
var courses = [
    {
        id: 0,
        courseBanner: "./Asset/images/c1.png",
        CourseCategories: "Art & Design",
        CoursePrice: "$29.28",
        CourseName: "Basic Fundamentals of Interior & Graphics Design",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 1,
        courseBanner: "./Asset/images/c2.png",
        CourseCategories: "Digital marketing",
        CoursePrice: "Free",
        CourseName: "Increasing Engagement with Instagram & Facebook",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 2,
        courseBanner: "./Asset/images/c3.png",
        CourseCategories: "Drawing",
        CoursePrice: "$72.39",
        CourseName: "Introduction to Color Theory & Basic UI/UX",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 3,
        courseBanner: "./Asset/images/c4.png",
        CourseCategories: "Finance",
        CoursePrice: "$72.39",
        CourseName: "Financial Security Thinking and Principles Theory",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 4,
        courseBanner: "./Asset/images/c5.png",
        CourseCategories: "Graphics",
        CoursePrice: "Free",
        CourseName: "Logo Design: From Concept to Presentation",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 5,
        courseBanner: "./Asset/images/c6.png",
        CourseCategories: "Development",
        CoursePrice: "$29.82",
        CourseName: "Professional Ceramic Moulding for Beginners",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 6,
        courseBanner: "./Asset/images/c1.png",
        CourseCategories: "Art & Design",
        CoursePrice: "$29.28",
        CourseName: "Basic Fundamentals of Interior & Graphics Design",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 7,
        courseBanner: "./Asset/images/c2.png",
        CourseCategories: "Digital marketing",
        CoursePrice: "Free",
        CourseName: "Increasing Engagement with Instagram & Facebook",
        CourseDescription: "Learn how to boost engagement on Instagram & Facebook. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in tellus nec orci feugiat sagittis. Duis sollicitudin euismod nisi, id consectetur mauris posuere nec. Aliquam vitae nulla eget nisi eleifend semper. Vestibulum condimentum massa sed ante congue tincidunt. Cras non felis vel nisi dictum feugiat non eget tellus. Donec dapibus mi ut vehicula mollis. Mauris eu elit in felis placerat vestibulum. Ut porta elit ac feugiat lobortis.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 8,
        courseBanner: "./Asset/images/c3.png",
        CourseCategories: "Drawing",
        CoursePrice: "$72.39",
        CourseName: "Introduction to Color Theory & Basic UI/UX",
        CourseDescription: "Get started with color theory and basic UI/UX design principles. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin id volutpat est. Sed eget lectus et augue porttitor commodo. Integer at lectus sed ipsum semper varius. Fusce euismod augue eu purus euismod, in consequat est pharetra. Sed nec justo quis enim eleifend rhoncus non in purus. Maecenas eu semper purus, non vestibulum felis. Nam vel risus eget mi fermentum tempor in vitae urna.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 9,
        courseBanner: "./Asset/images/c4.png",
        CourseCategories: "Finance",
        CoursePrice: "$72.39",
        CourseName: "Financial Security Thinking and Principles Theory",
        CourseDescription: "Learn about financial security thinking and principles theory. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt est ac nisi mattis efficitur. Nullam vitae metus vitae purus elementum tristique. Ut eu tortor condimentum, vestibulum leo ut, luctus ex. Vestibulum at nulla ac sapien accumsan viverra. Suspendisse potenti. Nulla convallis lorem nec turpis elementum fringilla. Curabitur ac leo id elit vehicula malesuada a nec orci.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 10,
        courseBanner: "./Asset/images/c5.png",
        CourseCategories: "Graphics",
        CoursePrice: "Free",
        CourseName: "Logo Design: From Concept to Presentation",
        CourseDescription: "Learn the process of logo design from concept to presentation. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla id sollicitudin lacus. Nullam ac purus in ligula ultricies tincidunt. Duis tincidunt auctor mi, nec pellentesque nisi sodales ac. Nam hendrerit ligula at velit lacinia lacinia. Integer luctus hendrerit purus, vel efficitur sem viverra sit amet. Duis convallis orci id enim iaculis, in ultricies metus vehicula.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 11,
        courseBanner: "./Asset/images/c6.png",
        CourseCategories: "Development",
        CoursePrice: "$29.82",
        CourseName: "Professional Ceramic Moulding for Beginners",
        CourseDescription: "Master ceramic moulding techniques for beginners. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vestibulum tellus vel lorem mollis aliquam. In non enim sit amet nisl aliquam efficitur vitae id dui. Proin id dapibus purus, non maximus lectus. Vestibulum eu libero elit. Aliquam quis tortor eget eros eleifend pharetra vel a urna. Vestibulum vehicula, magna a facilisis rutrum, mi eros tempus sapien, in congue quam justo non dui.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    }
];

var enrollcourses = [];

window.onload = () => {

    var Id = JSON.parse(localStorage.getItem('singleCourse'));

    enrollcourses = JSON.parse(localStorage.getItem('enrollcourses')) || [];

    single_course(Id);
}

function single_course(Id) {

    console.log("current_course :" + Id);

    document.getElementById('singleCourseContent').innerHTML = `
     
     <div class="d-flex flex-column justify-content-between align-items-start gap-5">
     <div class="course-img">
         <img src="${courses[Id].courseBanner}" alt="">
     </div>
     <div class="d-flex flex-column justify-content-center align-items-start gap-4">
         <button class="Course-categroies-single btn btn-danger">${courses[Id].CourseCategories}</button>
         <h4 class="Course-name-single">${courses[Id].CourseName}</h4>
         <ul class="nav nav-pills m-0 p-0" id="pills-tab" role="tablist">
             <li class="nav-item" role="presentation">
                 <button class="nav-link active pill-btn border-end first-radius"
                     id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home"
                     type="button" role="tab" aria-controls="pills-home"
                     aria-selected="true">Overview</button>
             </li>
             <li class="nav-item" role="presentation">
                 <button class="nav-link pill-btn border-end" id="pills-profile-tab"
                     data-bs-toggle="pill" data-bs-target="#pills-profile" type="button"
                     role="tab" aria-controls="pills-profile"
                     aria-selected="false">Carriculum</button>
             </li>
             <li class="nav-item" role="presentation">
                 <button class="nav-link pill-btn border-end" id="pills-contact-tab"
                     data-bs-toggle="pill" data-bs-target="#pills-contact" type="button"
                     role="tab" aria-controls="pills-contact"
                     aria-selected="false">Instructor</button>
             </li>
             <li class="nav-item" role="presentation">
                 <button class="nav-link pill-btn last-radius" id="pills-Review-tab"
                     data-bs-toggle="pill" data-bs-target="#pills-Review" type="button"
                     role="tab" aria-controls="pills-Review"
                     aria-selected="false">Reviews</button>
             </li>
         </ul>
         <div class="tab-content" id="pills-tabContent">
             <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                 aria-labelledby="pills-home-tab">
                 <h4 class="course-content-heading">Course Description</h4>
                 <p class="course-content-para">
                 ${courses[Id].CourseDescription}
                 </p>
             </div>
             <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                 aria-labelledby="pills-profile-tab">
                 <h4 class="course-content-heading">Course Carriculum</h4>
                 <div class="d-flex justify-content-start align-items-center gap-5 mt-4">
                     <h6 class="level">Level Beginner</h6>
                     <h6 class="lectures">12 Lectures</h6>
                     <h6 class="total-hours">Total: 5
                         Hours 56 Minutes 24 Seconds</h6>
                 </div>
                 <div class="accordion accordion-flush" id="accordionFlushExample">
                     <div class="accordion-item">
                         <h2 class="accordion-header" id="flush-headingOne">
                             <button class="accordion-button collapsed" type="button"
                                 data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                 aria-expanded="false" aria-controls="flush-collapseOne">
                                 Introduction
                             </button>
                         </h2>
                         <div id="flush-collapseOne" class="accordion-collapse collapse"
                             aria-labelledby="flush-headingOne"
                             data-bs-parent="#accordionFlushExample">
                             <div class="accordion-body">
                                 <h4 class="course-content-heading">Description</h4>
                                 <p class="course-content-para">This tutorial will help you learn
                                     quickly and
                                     thoroughly. Lorem ipsum, or
                                     lipsum as it sometimes known, is dummy text used in laying
                                     out print,
                                 </p>
                                 <div
                                     class="d-flex flex-lg-row flex-md-row flex-column justify-content-between align-items-start align-items-md-center align-items-lg-center">
                                     <div
                                         class="d-flex justify-content-start align-items-center gap-2">
                                         <img src="./Asset/images/camera.svg" class="pt-1 mt-1">
                                         <p class="course-content-para"> Video: Getting Started
                                             and Introductions</p>
                                     </div>
                                     <div
                                         class="d-flex justify-content-between align-items-center gap-3">
                                         <button type="button"
                                             class="preview mt-2">Preview</button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="accordion-item">
                         <h2 class="accordion-header" id="flush-headingTwo">
                             <button class="accordion-button collapsed" type="button"
                                 data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo"
                                 aria-expanded="false" aria-controls="flush-collapseTwo">
                                 Getting Started
                             </button>
                         </h2>
                         <div id="flush-collapseTwo" class="accordion-collapse collapse"
                             aria-labelledby="flush-headingTwo"
                             data-bs-parent="#accordionFlushExample">
                             <div class="accordion-body">
                                 <h4 class="course-content-heading">Description</h4>
                                 <p class="course-content-para">This tutorial will help you learn
                                     quickly and
                                     thoroughly. Lorem ipsum, or
                                     lipsum as it sometimes known, is dummy text used in laying
                                     out print,
                                 </p>
                                 <div class="d-flex flex-lg-row flex-md-row flex-column justify-content-between align-items-start align-items-md-center align-items-lg-centerr">
                                     <div
                                         class="d-flex justify-content-start align-items-center gap-2">
                                         <img src="./Asset/images/camera.svg" class="pt-1 mt-1">
                                         <p class="course-content-para"> Video: Getting Started
                                             and Introductions</p>
                                     </div>
                                     <div>
                                         <button type="button"
                                             class="preview mt-2">Preview</button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="accordion-item">
                         <h2 class="accordion-header" id="flush-headingThree">
                             <button class="accordion-button collapsed" type="button"
                                 data-bs-toggle="collapse" data-bs-target="#flush-collapseThree"
                                 aria-expanded="false" aria-controls="flush-collapseThree">
                                 Start from Sketch Design
                             </button>
                         </h2>
                         <div id="flush-collapseThree" class="accordion-collapse collapse"
                             aria-labelledby="flush-headingThree"
                             data-bs-parent="#accordionFlushExample">
                             <div class="accordion-body">
                                 <h4 class="course-content-heading">Description</h4>
                                 <p class="course-content-para">This tutorial will help you learn
                                     quickly and
                                     thoroughly. Lorem ipsum, or
                                     lipsum as it sometimes known, is dummy text used in laying
                                     out print,
                                 </p>
                                 <div class="d-flex flex-lg-row flex-md-row flex-column justify-content-between align-items-start align-items-md-center align-items-lg-center">
                                     <div
                                         class="d-flex justify-content-start align-items-center gap-2">
                                         <img src="./Asset/images/camera.svg" class="pt-1 mt-1">
                                         <p class="course-content-para"> Video: Getting Started
                                             and Introductions</p>
                                     </div>
                                     <div>
                                         <button type="button"
                                             class="preview mt-2">Preview</button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="accordion-item">
                         <h2 class="accordion-header" id="flush-headingFour">
                             <button class="accordion-button collapsed" type="button"
                                 data-bs-toggle="collapse" data-bs-target="#flush-collapseFour"
                                 aria-expanded="false" aria-controls="flush-collapseFour">
                                 Getting Help & Support in Seller Central
                             </button>
                         </h2>
                         <div id="flush-collapseFour" class="accordion-collapse collapse"
                             aria-labelledby="flush-headingFour"
                             data-bs-parent="#accordionFlushExample">
                             <div class="accordion-body">
                                 <h4 class="course-content-heading">Description</h4>
                                 <p class="course-content-para">This tutorial will help you learn
                                     quickly and
                                     thoroughly. Lorem ipsum, or
                                     lipsum as it sometimes known, is dummy text used in laying
                                     out print,
                                 </p>
                                 <div class="d-flex flex-lg-row flex-md-row flex-column justify-content-between align-items-start align-items-md-center align-items-lg-center">
                                     <div
                                         class="d-flex justify-content-start align-items-center gap-2">
                                         <img src="./Asset/images/camera.svg" class="pt-1 mt-1">
                                         <p class="course-content-para"> Video: Getting Started
                                             and Introductions</p>
                                     </div>
                                     <div>
                                         <button type="button"
                                             class="preview mt-2">Preview</button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                 aria-labelledby="pills-contact-tab">
                 <div class="instructor">
                     <div class="instructor-row">
                         <div class="instructor-left">
                             <img src="./Asset/images/instructor.png" alt="instructor">
                         </div>
                         <div class="instructor-right">
                             <h4 class="instructor-heading">Daniel Smith</h4>
                             <h6 class="instructor-subheading">User Experience Designer</h6>
                             <ul class="m-0 p-0 mt-2 d-flex flex-column gap-3">
                                 <li class="d-flex gap-3"><img src="./Asset/images/file2.svg"
                                         alt="file"><span class="instructor-info">65+
                                         Courses</span>
                                 </li>
                                 <li class="d-flex gap-3"><img src="./Asset/images/user2.svg"
                                         alt="file"><span class="instructor-info">2k+ Student
                                         Learned</span>
                                 </li>
                                 <li class="d-flex gap-3"><img src="./Asset/images/star (1).svg"
                                         alt="file"><span class="instructor-info">547+
                                         Reviews</span>
                                 </li>
                                 <li class="d-flex gap-3"><img src="./Asset/images/like.svg"
                                         alt="file"><span class="instructor-info">4.9
                                         Rating</span>
                                 </li>
                             </ul>
                             <div class="d-flex gap-3 mt-3">
                                 <a href="#"><img src="./Asset/images/fb.svg" alt="fb"></a>
                                 <a href="#"><img src="./Asset/images/ln.svg" alt="fb"></a>
                                 <a href="#"><img src="./Asset/images/youtube.svg" alt="fb"></a>
                                 <a href="#"><img src="./Asset/images/instra.svg" alt="fb"></a>
                                 <a href="#"><img src="./Asset/images/twiiter.svg" alt="fb"></a>
                             </div>
                         </div>
                     </div>
                     <div>
                         <p class="course-content-para">This tutorial will help you learn quickly
                             and
                             thoroughly. Lorem ipsum, or
                             lipsum as it sometimes known, is dummy text used in laying out
                             print,
                             graphic or web designs. Lorem ipsum dolor sit amet, consectetuer
                             adipiscing
                             elit. Donec odio. Quisque volutpat mattis eros.
                         </p>
                     </div>
                 </div>
             </div>
             <div class="tab-pane fade" id="pills-Review" role="tabpanel"
                 aria-labelledby="pills-Review-tab">
                 <h4 class="course-content-heading">Reviews</h4>
                 <div class="Reviews-box">
                     <div class="Reviews mt-4">
                         <img src="./Asset/images/cmnt-1.png" alt="profile">
                         <div
                             class="d-flex flex-column justify-content-center align-items-start gap-2 mt-4">
                             <div class="d-flex justify-content-center align-items-center gap-2">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                             </div>
                             <p class="Reviews-para">There are many variations of passages of
                                 Lorem Ipsum available, but the majority have suffered
                                 alteration.
                             </p>
                             <h5 class="m-0 p-0">Daniel Smith</h5>
                         </div>
                     </div>
                     <div class="Reviews mt-4 mb-lg-0 mb-md-0 mb-3">
                         <img src="./Asset/images/cmnt-2.png" alt="profile">
                         <div
                             class="d-flex flex-column justify-content-center align-items-start gap-2 mt-4">
                             <div class="d-flex justify-content-center align-items-center gap-2">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                                 <img src="./Asset/images/star-yellow.png" alt="star">
                             </div>
                             <p class="Reviews-para">There are many variations of passages of
                                 Lorem Ipsum available, but the majority have suffered
                                 alteration.
                             </p>
                             <h5 class="m-0 p-0">Daniel Smith</h5>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
     
     `
    document.getElementById('singleCourseSiderbar').innerHTML = `
    
  <div class="thumb">
  <img class="course-img" src="./Asset/images/thumb.png" alt="">
  <img src="./Asset/images/play.svg" class="play-icon" alt="play-icon">
</div>
<h5 class="course-title">${courses[Id].CoursePrice}</h5>
<button type="button" class="enroll" onclick ="enroll(${Id})">
  Enroll Now
</button>
<div class="course-info mt-3">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/user.svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1">Instructor</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          Daniel Smith
      </p>
  </div>
</div>
<div class="course-info">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/file2.svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1"> Lectures</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          23
      </p>
  </div>
</div>
<div class="course-info">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/clock.svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1">Duration</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          2Hr 36Minutes
      </p>
  </div>
</div>
<div class="course-info">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/star (1).svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1">Enrolled</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          2k Students
      </p>
  </div>
</div>
<div class="course-info">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/target (1).svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1">Course level</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          Intermediate
      </p>
  </div>
</div>
<div class="course-info-2">
  <div class="d-flex gap-3 justify-content-start align-items-center">
      <img src="./Asset/images/web.svg" class="courser-info-logo" alt="user">
      <h5 class="m-0 p-0 course-info-heading mt-1">Language</h5>
  </div>
  <div>
      <p class="course-info-name mt-1">
          English
      </p>
  </div>
</div>
  
  `

    document.getElementById('singleCourseSiderbar-2').innerHTML = `
  
  <div class="d-flex flex-column gap-2">
  <div>
      <h5 class="course-title-2">Related Courses</h5>
  </div>
  <div class="d-flex justify-content-between align-items-center gap-3">
      <div class="related-course d-flex flex-column gap-4 mt-3">
          <div
              class="related-course-card d-flex justify-content-between align-items-center gap-4">
              <div class="r-card-image">
                  <img src="./Asset/images/rc-1.png" alt="rc">
              </div>
              <div class="d-flex flex-column justify-content-center align-items-start">
                  <h5 class="r-course-name">UI/UX Design and Graphics</h5>
                  <span class="r-course-price">$20</span>
              </div>
          </div>
          <div
              class="related-course-card d-flex justify-content-between align-items-center gap-4">
              <div class="r-card-image">
                  <img src="./Asset/images/rc-2.png" alt="rc">
              </div>
              <div class="d-flex flex-column justify-content-center align-items-start">
                  <h5 class="r-course-name">UI/UX Design and Graphics</h5>
                  <span class="r-course-price">$20</span>
              </div>
          </div>
      </div>
  </div>
</div>
  
  `
}

console.log(enrollcourses.length);

function enroll(id) {

    console.log('enroll click');
    var Id = id

    localStorage.setItem('enroll', JSON.stringify(Id));

    var valid = enrollcourses.find(item => item.buycourse == Id)

    if (valid) {

        alert('course alrady buy');

        document.getElementById('autocall').click();

    } else {
        window.location.href = 'checkout.html';
    }

}
